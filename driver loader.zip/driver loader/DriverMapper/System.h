#pragma once
#include <Windows.h>

DWORD64 GetSystemModuleBaseAddress(const char* ModuleName);